package com.example

import android.app.Application
import com.example.di.AppContainer

class SovereignApplication : Application() {
    lateinit var container: AppContainer

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
